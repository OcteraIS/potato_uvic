#!/usr/bin/env python
from potato.flask_server import main
from potato import *

def potato():
    main()


if __name__ == '__main__':
    potato()